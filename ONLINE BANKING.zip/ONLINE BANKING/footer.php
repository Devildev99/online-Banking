<link rel="stylesheet" type="text/css" href="css/footer.css">
<footer>
<div class="container">
<div class="follow_us">
     <h3>ADPP <span>Banking Services</span></h3>
    <label>Follow Us</label>
    <ul>
        <li><a href="https://www.facebook.com/">Facebook</a></li>
        <li><a href="https://twitter.com/">Twitter</a></li>
        <li><a href="https://www.instagram.com/">Instagram</a></li>
        <li><a href="https://www.youtube.com/">YouTube</a></li>
    
    </ul>
    </div>
    <div class="contact" id="contactus">
        <label>Contact Us</label>
        <ul>
            <p>Sabarmati Road,</p><p>Karnataka</p>
            <p>PH:7478990258</p>
            <p> EMAIL: adppbank143</p>
            <p>@adppservice.co.in</p>
            
        </ul>
    </div>
        <div class="links">
            <label>Important Links</label>
            <ul>    
            <li><a href="index.php#aboutus" target="_blank">About Us</a></li>
            <li><a href="#">Loan</a></li>
            <li><a href="Basic Calculator.php">Calculator</a></li> 
            </ul><br>
    </div>

    <div class="links">
            <label>Important Links</label>
            <ul>    
            <li><a href="index.php#aboutus" target="_blank">Link 1</a></li>
            <li><a href="">Link 2</a></li>
            <li><a href="">Link 3</a></li> 
            </ul><br>
    </div>
    
    
    </div>
    <div class="copyright">
        <span>Copyright @2022-24 &copy;<strong>aldepripa Solutech</strong> All rights reserved</span>
    </div>
    
    <div class="bestview">
    <span>Site best viewed at 1024 x 768 resolution in Internet Explorer 10+, Google Chrome 49+, Firefox 45+ and Safari 6+</span>
    
    </div>

</footer>