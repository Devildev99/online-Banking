<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>ADPP Bank ~India ki tej Bank</title>
	<!--<link rel="stylesheet" type="text/css" href="css/logout.css">-->
	<link rel="shortcut icon" href="img/LOGO.png">
	<style>
		body{
			margin: 0;
			padding: 0;
			font-family: arial;
		}
.container{
	position: absolute;
	left: 0;
	top: 0;
	width: 100%;
	height: 100vh;
	animation: animate 16s ease-in-out infinite;
	background-size: cover;
}
.outer{
	position: absolute;
	left: 0;
	top: 0;
	width: 100%;
	height: 100vh;
	background: rgba(0, 0, 0, 0.5);

}
.details{
	position: absolute;
	left: 50%;
	top: 50%;
	transform: translate(-50%, -50%);
	text-align: center;
}
h1{
	font-size: 3em;
	color: antiquewhite;
}
.details h2 span:nth-child(1){
	color:  darkred;
	font-size: 25px;

}
.details h2 span:nth-child(2){
	color: gold;
	font-size: 25px;

}
.details p{
	font-size: 22px;
	font-family: century;
	font-style: bold;
	color: lightgoldenrodyellow;
}
@keyframes animate{
	0%{
		background-image: url(img/background.jpg);
	}
	25%{
		background-image: url(img/background2.jpg);
	}
	50%{
		background-image: url(img/background.jpg);
	}
	75%{
		background-image: url(img/background2.jpg);
	}

}
	</style>
</head>
<body>
	<div class="container">
		<div class="outer">
			<div class="details">
				<h1>You have Successfully Logged out</h1>
				<h2>
					<span><b>Thank You</b></span>
					<span></span>
					<span><a href="customer_logout.php"><b>Visit Again</b></a></span>
				</h2>

				<p>If You Faced Any Kind of Problem, Please Visit Your Nearest Branch.... Thank You for Choose our Services.</p> 
				
			</div>
			
		</div>
	</div>
</body>
</html>