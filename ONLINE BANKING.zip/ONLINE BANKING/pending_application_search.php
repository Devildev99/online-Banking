<html>
<head><title>Active Customers</title>
</head>
<link rel="stylesheet" type="text/css" href="css/active_customers.css"/>
<body>

<?php  

	include 'header.php' ;
	include 'staff_profile_header.php' ;
	include 'db_connect.php';


?>
<div class="pending_appli_container">


</div>

<?php include 'footer.php'; ?> 
</body>
</html>




