<!DOCTYPE htaml>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Simple Header - CodeWith Random</title>
        <link rel="stylesheet" type="text/css" href="css/header.css">
        <link rel="shortcut icon" href="img/LOGO.png">
    </head>
    <body>
        
        <div class="navbar">
            <img src="img/LOGO.png" class="logo">
        <header class="site-header">
            <div class="site-identity">
                <h1><a href="index.php#aboutus">ADPP Bank ~India ki tej Bank</a></h1>
            </div>
            <nav class="site-navigation">
                <ul class="nav">
                    <li><b><a href="index.php">Home</a></b></li>
                    <li><b><a href="">About</a></b></li>
                    <li><b><a href="#">Blog</a></b></li>
                    <li><b><a href="#">Contact</a></b></li>
                </ul>
            </nav>
        </header>
    </body>
</html>