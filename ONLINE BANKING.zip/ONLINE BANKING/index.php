<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ADPP Bank ~India ki tej Bank</title>
    <link rel="stylesheet" type="text/css" href="css/index.css">
    <link rel="shortcut icon" href="img/LOGO.png">
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <img src="img/LOGO.png" class="logo">
            <nav>
                <ul>
                    <li><a href="#">HOME</a></li>
                     
                      <li><a href="staff_login.php">STAFF LOGIN</a></li>
                       <li>
                        <a href="">LOAN<i class="fas fa-caret-down"></i></a>
                        <div class="dropdown">
                            <ul>
                                <li><a href="">EDUCATION LOAN</a></li>
                                <li><a href="">PROPERTY LOAN</a></li>
                                <li><a href="">GOLD LOAN</a></li>
                                <li><a href="">CAR LOAN</a></li>
                            </ul>
                        </div>

                        </li>
                       
                        <li><a href="">NOTICES</a></li>
                        <li><a href="fund_transfer.php">FUND TRANSFER</a></li>
                        <li><a href="feedback.php">FEEDBACK</a></li><br><br>
                        

                        <b><marquee scrollbar ="5", bgcolor="lavenderblush",direction="right">Welcome to India's most Promising and beleveable Bank. Namastey</marquee></b>
                    
                    
                </ul>
            </nav>
        
                    <div class="row">
                        <div class="col">
                           <h1><b>ADPP ~India ki tej Bank!</h1></b> 
                          <p>*First, open an account. Then apply for a debit card to get further details.</p><br><br>
                          <p>*And finally, proceed for Internet Banking Registration to create your internet banking account</p><br>
                          <a href="customer_reg_form.php"><button type="">Account</button>
                          <a href="debit_card_form.php"><button type="">Debit Card</button>
                          <a href="customer_login.php"><button type="">Login</button>
                          <a href="ebanking_reg_form.php"><button type="">Register</button>

                          <div class="wrapper">
                            <div class="search-input">
                            <a href="" target="_blank" hidden></a>
                            <input type="text" placeholder="Type to search..">
                            <div class="autocom-box">
                            <!-- here list are inserted from javascript -->
                            </div>
                             <div class="icon"><i class="fas fa-search"></i></div>
                            </div>
                              </div>
                              <script src="js/suggestions.js"></script> 
                              <script src="js/script.js"></script>       
                    
                            
                        </div>
                        <div class="col">
                            <div class="card card1">
                                <h5>.</h5>
                                
                            </div>
                            <div class="card card2">
                                 <h5>.</h5>
                                
                            </div>
                            <div class="card card3">
                                 <h5>secure Transfer</h5>
                                
                            </div>
                            <div class="card card4">
                                 <h5>Locker facility</h5>
                                
                            </div>
                        </div>
                        
                    </div>


            </div>
    </div>

    



</body>

<footer class="footer-distributed">

        <div class="footer-left">
            <h3>ADPP <span>Banking Services</span></h3>

            <p class="footer-links">
                <a href="#">Home</a>
                |
                <a href="#">About</a>
                
                |
                <a href="#">Contact</a>
                |
                <a href="Basic Calculator.php">Calculator</a>
            </p>

            <p class="footer-company-name">Copyright © 2022-24 <strong>aldepripa Solutech</strong> All rights reserved</p>
        </div>

        <div class="footer-center">
            <div>
                <i class="fa fa-map-marker"></i>
                <p><span>Sabarmati Road</span>
                    Whitefield , Bangalore,
                    Karnataka</p>
            </div>

            <div>
                <i class="fa fa-phone"></i>
                <p>+91 7478990258</p>
            </div>
            <div>
                <i class="fa fa-envelope"></i>
                <p><a href="#">adppbank143@adppservice.co.in</a></p>
            </div>
        </div>
        <div class="footer-right">
            <p class="footer-company-about">
                <span>Our Target</span>
                <strong>Our moto</strong> We are simply providing the best customer experience with 0% of wasting of time.This is Our moto. Thanks For Choosing Us.
            </p>
            <div class="footer-icons">
                <script src="https://kit.fontawesome.com/a076d05399.js"></script>
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-linkedin"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
    </footer>



</html>