<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>ADPP Bank ~India ki tej Bank Feedback</title>
	<link rel="stylesheet" type="text/css" href="css/feedback.css">
    <link rel="shortcut icon" href="img/LOGO.png">
    <script src="https://kit.fontawesome.com/67c66657c7.js"></script>
</head>
<body>
	<div class="container">
		<form>
			<h1>Give Your Feedback</h1>
			<div class="id">
				<input type="text" placeholder="Enter Your Full Name">
				<i class="far fa-user"></i>
				</div>
				<div class="id">
				<input type="email" placeholder="Enter Your Proper Email">
				<i class="far fa-envelope"></i>
				
				</div>
				<textarea cols="16" rows="6" placeholder="Enter Your Opinion Here"></textarea>
				<button>Send</button>
		</form>
		
	</div>

</body>
</html>